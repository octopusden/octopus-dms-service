MAVEN release artifact
