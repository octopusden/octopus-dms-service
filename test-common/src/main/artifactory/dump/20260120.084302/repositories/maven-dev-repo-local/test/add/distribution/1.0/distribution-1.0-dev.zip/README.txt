MAVEN staging artifact
